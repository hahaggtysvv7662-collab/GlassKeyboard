package com.example.glasskeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val pickCode = 101

    private fun prefs() = getSharedPreferences("kb", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(56), px(24), px(32))
        }
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1A1055.toInt(), 0xFF0B3B6B.toInt(), 0xFF4A1A6B.toInt())
            )
            addView(root)
        }

        fun text(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, px(6), 0, px(6))
        }

        fun glassButton(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setTextColor(Color.WHITE)
            isAllCaps = false
            textSize = 16f
            background = GradientDrawable().apply {
                cornerRadius = px(28).toFloat()
                setColor(0x44FFFFFF)
                setStroke(px(1), 0xAAFFFFFF.toInt())
            }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, px(54)
            ).apply { topMargin = px(10) }
        }

        fun section(t: String) = text(t, 15f).apply { setPadding(0, px(22), 0, px(6)) }

        root.addView(text("Liquid Glass Keyboard", 26f, true))
        root.addView(section("ধাপ ১: কিবোর্ডটি চালু করুন"))
        root.addView(glassButton("কিবোর্ড চালু করুন") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(section("ধাপ ২: কিবোর্ড বেছে নিন"))
        root.addView(glassButton("কিবোর্ড বেছে নিন") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        // colour
        root.addView(section("রঙ বেছে নিন"))
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("বেগুনি", "নীল", "গোলাপি", "সবুজ", "RGB")
        names.forEachIndexed { i, n ->
            colorRow.addView(Button(this).apply {
                text = n
                textSize = 12f
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = px(14).toFloat()
                    setColor(0x33FFFFFF)
                    setStroke(px(1), 0xAAFFFFFF.toInt())
                }
                setOnClickListener { prefs().edit().putInt("accent", i).apply() }
                layoutParams = LinearLayout.LayoutParams(0, px(44), 1f).apply { marginEnd = px(4) }
            })
        }
        root.addView(colorRow)

        // height
        val sizeLabel = text("", 15f)
        val seek = SeekBar(this).apply {
            max = 60
            progress = (prefs().getInt("heightPct", 100) - 75).coerceIn(0, 60)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = 75 + p
                    sizeLabel.text = "কিবোর্ডের উচ্চতা: $v%"
                    if (fromUser) prefs().edit().putInt("heightPct", v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sizeLabel.text = "কিবোর্ডের উচ্চতা: ${75 + seek.progress}%"
        root.addView(section("কিবোর্ডের সাইজ"))
        root.addView(sizeLabel)
        root.addView(seek)

        // switches
        fun toggle(label: String, key: String, def: Boolean) = Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 16f
            isChecked = prefs().getBoolean(key, def)
            setPadding(0, px(10), 0, px(10))
            setOnCheckedChangeListener { _, on -> prefs().edit().putBoolean(key, on).apply() }
        }
        root.addView(section("সেটিংস"))
        root.addView(toggle("বাংলা কিবোর্ড (বাং বাটন)", "bangla", true))
        root.addView(toggle("টাইপের শব্দ", "sound", true))

        // landscape
        root.addView(section("ফোন আড়াআড়ি (ল্যান্ডস্কেপ)"))
        root.addView(text("ফোন ঘোরালে কিবোর্ড নিজে ছোট হয়ে যাবে। কিবোর্ডের বাঁ, ডান ও ওপরের ধারের সাদা দাগ টেনে সাইজ ও জায়গা ঠিক করুন।", 14f))
        root.addView(glassButton("ল্যান্ডস্কেপ সাইজ রিসেট") {
            prefs().edit().remove("lsL").remove("lsR").remove("lsH").apply()
            Toast.makeText(this, "রিসেট হয়েছে", Toast.LENGTH_SHORT).show()
        })

        // photo
        root.addView(section("ব্যাকগ্রাউন্ড ছবি"))
        root.addView(glassButton("গ্যালারি থেকে ছবি বেছে নিন") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, pickCode)
        })
        root.addView(glassButton("ছবি সরান") {
            prefs().edit().remove("bg").apply()
            File(filesDir, "bg.jpg").delete()
            Toast.makeText(this, "ছবি সরানো হয়েছে", Toast.LENGTH_SHORT).show()
        })

        root.addView(section("নিচের ঘরে টাইপ করে দেখুন"))
        root.addView(EditText(this).apply {
            hint = "এখানে টাইপ করুন"
            setTextColor(Color.WHITE)
            setHintTextColor(0xAAFFFFFF.toInt())
            gravity = Gravity.TOP
            minLines = 3
        })
        setContentView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) saveBackground(uri)
        }
    }

    private fun saveBackground(uri: Uri) {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sample = 1
            val longest = maxOf(o.outWidth, o.outHeight)
            while (longest / sample > 1600) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) {
                Toast.makeText(this, "ছবি যোগ করা যায়নি", Toast.LENGTH_SHORT).show()
                return
            }
            val f = File(filesDir, "bg.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            prefs().edit().putString("bg", f.absolutePath).apply()
            Toast.makeText(this, "ছবি যোগ হয়েছে", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ছবি যোগ করা যায়নি", Toast.LENGTH_SHORT).show()
        }
    }
}
