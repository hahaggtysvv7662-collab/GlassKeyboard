package com.example.glasskeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(64), px(24), px(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1A1055.toInt(), 0xFF0B3B6B.toInt(), 0xFF4A1A6B.toInt())
            )
        }

        fun text(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, px(6), 0, px(6))
        }

        fun glassButton(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setTextColor(Color.WHITE)
            isAllCaps = false
            textSize = 16f
            background = GradientDrawable().apply {
                cornerRadius = px(28).toFloat()
                setColor(0x44FFFFFF)
                setStroke(px(1), 0xAAFFFFFF.toInt())
            }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, px(56)
            ).apply { topMargin = px(12) }
        }

        root.addView(text("Liquid Glass Keyboard", 26f, true))
        root.addView(text("ধাপ ১: নিচের বাটনে চেপে কিবোর্ডটি চালু করুন", 15f))
        root.addView(glassButton("কিবোর্ড চালু করুন") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(text("ধাপ ২: কিবোর্ড বেছে নিন", 15f).apply { setPadding(0, px(20), 0, px(6)) })
        root.addView(glassButton("কিবোর্ড বেছে নিন") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        root.addView(text("রঙ বেছে নিন (পরের বার কিবোর্ড খুললে বদলে যাবে)", 15f).apply { setPadding(0, px(20), 0, px(6)) })
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("বেগুনি", "নীল", "গোলাপি", "সবুজ", "RGB")
        names.forEachIndexed { i, n ->
            colorRow.addView(Button(this).apply {
                text = n
                textSize = 12f
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = px(14).toFloat()
                    setColor(0x33FFFFFF)
                    setStroke(px(1), 0xAAFFFFFF.toInt())
                }
                setOnClickListener {
                    getSharedPreferences("kb", MODE_PRIVATE).edit().putInt("accent", i).apply()
                }
                layoutParams = LinearLayout.LayoutParams(0, px(44), 1f).apply { marginEnd = px(4) }
            })
        }
        root.addView(colorRow)
        root.addView(text("ধাপ ৩: নিচের ঘরে টাইপ করে দেখুন", 15f).apply { setPadding(0, px(20), 0, px(6)) })
        root.addView(EditText(this).apply {
            hint = "এখানে টাইপ করুন"
            setTextColor(Color.WHITE)
            setHintTextColor(0xAAFFFFFF.toInt())
            gravity = Gravity.TOP
            minLines = 3
        })
        setContentView(root)
    }
}
