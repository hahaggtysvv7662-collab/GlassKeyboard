package com.example.glasskeyboard

object Words {
    private val list: List<String> by lazy { RAW.split(" ").filter { it.isNotEmpty() }.distinct() }

    fun suggest(prefix: String, max: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val p = prefix.lowercase()
        val out = ArrayList<String>()
        for (w in list) {
            val lw = w.lowercase()
            if (lw.length > p.length && lw.startsWith(p)) {
                out.add(if (prefix[0].isUpperCase()) w.replaceFirstChar { it.uppercase() } else w)
                if (out.size >= max) break
            }
        }
        return out
    }

    private const val RAW = "the be to of and a in that have I it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did said each tell does hello thanks thank please sorry welcome happy birthday today tomorrow yesterday really maybe everything something anything someone everyone morning night love friend family money phone message call send reply okay yes great nice beautiful awesome amazing keyboard type typing write read book learn study school college office home house room door city country world life light hand head face eyes heart mind water food eat drink sleep walk run play game music song movie video photo picture camera internet online website email account password number name address place where here there away around always never sometimes often usually before again against nothing without within through between during while until since because though although however whatever whenever wherever together another other others every either neither both several many much more most less least enough quite rather very too also still already yet just only even almost perhaps probably possible important different difficult easy hard simple small large little long short high low old young early late fast slow right wrong true false best better worse worst first last next previous second third three four five six seven eight nine ten hundred thousand million question answer problem solution idea thought reason result change start begin end finish stop continue keep stay leave arrive return follow lead help support need want wish hope believe understand remember forget decide choose try use make build create design develop open close turn move bring carry take give show tell ask call talk speak listen hear watch look find search meet join share buy sell pay cost price free paid power force energy fire air earth sun moon star sky rain wind snow cold hot warm dark white black red blue green yellow brown pink purple orange gold silver night evening afternoon week month year minute hour second weekend monday tuesday wednesday thursday friday saturday sunday"
}
