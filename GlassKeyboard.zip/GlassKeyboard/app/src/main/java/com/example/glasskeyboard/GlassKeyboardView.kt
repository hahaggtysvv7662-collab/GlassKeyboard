package com.example.glasskeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Neon RGB keyboard: dark keycaps, glowing edges, jelly spring, emoji, suggestions, photo background. */
class GlassKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onBackspace()
        fun onEnter()
        fun onReplace(typed: String, word: String)
    }

    var listener: Listener? = null

    private class Key(val label: String, val weight: Float) {
        val rect = RectF()
        var pos = 0f
        var vel = 0f
        var target = 0f
        var bub = 0f
        var bubVel = 0f
        var kicked = true
        var holdUntil = 0L
        var fill: Shader? = null
    }

    private class Ripple(val x: Float, val y: Float, val t0: Long, val color: Int)

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun w(str: String) = str.split(" ")

    private val tabLabels = listOf("😀", "👋", "🐱", "🍔", "⚽", "🚗", "💡", "\u2764\uFE0F", "🏁")
    private val specials = setOf("⇧", "⌫", "↵", "123", "ABC", "বাং", "EN", "অআ", "কখ", "😊") + tabLabels

    private val layouts: Map<String, List<List<String>>> = mapOf(
        "EN" to listOf(
            w("q w e r t y u i o p"),
            w("a s d f g h j k l"),
            w("⇧ z x c v b n m ⌫"),
            w("123 😊 বাং , SPACE . ↵")
        ),
        "BN1" to listOf(
            w("ক খ গ ঘ ঙ চ ছ জ ঝ ঞ"),
            w("ট ঠ ড ঢ ণ ত থ দ ধ ন"),
            w("প ফ ব ভ ম য র ল শ ⌫"),
            w("অআ EN SPACE । ↵")
        ),
        "BN2" to listOf(
            w("অ আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ"),
            w("া ি ী ু ূ ৃ ে ৈ ো ৌ"),
            w("ষ স হ ড\u09BC ঢ\u09BC য\u09BC ৎ ং ঃ ঁ"),
            w("কখ ্ SPACE ⌫ ↵")
        ),
        "NUM" to listOf(
            w("1 2 3 4 5 6 7 8 9 0"),
            w("১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯ ০"),
            w("@ # ৳ & - + ( ) ? !"),
            w("ABC , SPACE . ⌫ ↵")
        ),
        "EMOJI" to listOf(
            w("ABC 😀 👋 🐱 🍔 ⚽ 🚗 💡 \u2764\uFE0F 🏁 ⌫")
        )
    )

    // settings
    private val accents = intArrayOf(0xFFB026FF.toInt(), 0xFF2D9CFF.toInt(), 0xFFFF2D95.toInt(), 0xFF2DFF8A.toInt())
    private var accentIndex = 0
    private var banglaOn = true
    private var soundOn = true
    private var heightScale = 1f
    private val hsv = FloatArray(3)

    // state
    private var mode = "EN"
    private var shift = false
    private var keys: List<List<Key>> = emptyList()
    private val ripples = mutableListOf<Ripple>()
    private val word = StringBuilder()
    private var suggestions: List<String> = emptyList()

    // emoji
    private var emojiCats: List<List<String>> = emptyList()
    private var emojiTab = 0
    private val gridRect = RectF()
    private var gridScroll = 0f
    private var flingV = 0f
    private var gridPointer = -1
    private var gridDownX = 0f
    private var gridDownY = 0f
    private var gridLastX = 0f
    private var gridMoved = false
    private var vt: VelocityTracker? = null
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    // photo background
    private var bgBitmap: Bitmap? = null
    private var bgKey: String? = null
    private val bgSrc = Rect()
    private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    // time / intro
    private val start = System.nanoTime()
    private var last = start
    private var timeSec = 0f
    private var introT0 = 0L

    // geometry
    private val inset = dp(46f)
    private val margin = dp(6f)
    private val panelRadius = dp(22f)
    private val panel = RectF()
    private val panelPath = Path()
    private val bubblePath = Path()

    // paints
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
    private val tmp = RectF()

    private val glowW = floatArrayOf(9f, 5.5f, 2.6f)
    private val glowA = intArrayOf(45, 85, 150)

    // input
    private val active = HashMap<Int, Key>()
    private val handler = Handler(Looper.getMainLooper())
    private var repeatKey: Key? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            if (repeatKey != null) {
                listener?.onBackspace()
                if (word.isNotEmpty()) { word.deleteCharAt(word.length - 1); updateSuggestions() }
                handler.postDelayed(this, 45)
            }
        }
    }

    // sound
    private var clickA: AudioTrack? = null
    private var clickB: AudioTrack? = null

    init {
        setMode("EN")
        buildEmojis()
    }

    // ------------------------------------------------------------------ settings

    fun setAccent(i: Int) { accentIndex = i.coerceIn(0, 4) }

    fun applySettings(accent: Int, heightPct: Int, bangla: Boolean, sound: Boolean, bgPath: String?) {
        accentIndex = accent.coerceIn(0, 4)
        val hs = heightPct.coerceIn(70, 135) / 100f
        if (abs(hs - heightScale) > 0.001f) {
            heightScale = hs
            requestLayout()
        }
        soundOn = sound
        if (bangla != banglaOn) {
            banglaOn = bangla
            setMode(if (!bangla && mode.startsWith("BN")) "EN" else mode)
        }
        loadBackground(bgPath)
    }

    fun resetWord() {
        word.setLength(0)
        suggestions = emptyList()
    }

    fun playIntro() {
        introT0 = System.nanoTime()
        keys.forEach { row -> row.forEach { it.kicked = false } }
    }

    private fun loadBackground(path: String?) {
        if (path == null) {
            bgBitmap = null
            bgKey = null
            return
        }
        val f = File(path)
        val key = path + f.lastModified()
        if (key == bgKey) return
        bgKey = key
        bgBitmap = try { BitmapFactory.decodeFile(path) } catch (e: Exception) { null }
        computeBgSrc()
    }

    private fun computeBgSrc() {
        val bmp = bgBitmap ?: return
        if (panel.width() <= 0f || panel.height() <= 0f) return
        val pr = panel.width() / panel.height()
        val br = bmp.width / bmp.height.toFloat()
        if (br > pr) {
            val sw = (bmp.height * pr).toInt()
            val l = (bmp.width - sw) / 2
            bgSrc.set(l, 0, l + sw, bmp.height)
        } else {
            val sh = (bmp.width / pr).toInt()
            val t = (bmp.height - sh) / 2
            bgSrc.set(0, t, bmp.width, t + sh)
        }
    }

    // ------------------------------------------------------------------ colours

    private fun withAlpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun mixWhite(color: Int, f: Float): Int {
        val r = ((color shr 16 and 0xFF) + (255 - (color shr 16 and 0xFF)) * f).toInt()
        val g = ((color shr 8 and 0xFF) + (255 - (color shr 8 and 0xFF)) * f).toInt()
        val b = ((color and 0xFF) + (255 - (color and 0xFF)) * f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun accentAt(x: Float, y: Float): Int {
        if (accentIndex < 4) return accents[accentIndex]
        hsv[0] = (timeSec * 70f + x / (if (width > 0) width else 1) * 220f + y * 0.15f) % 360f
        hsv[1] = 0.85f
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    // ------------------------------------------------------------------ layout

    private fun layoutFor(m: String): List<List<String>> {
        val base = layouts.getValue(m)
        if (banglaOn) return base
        return when (m) {
            "EN" -> base.take(3) + listOf(w("123 😊 , SPACE . ↵"))
            "NUM" -> listOf(base[0], w("~ | ^ = / < > [ ] _"), w("@ # \$ & - + ( ) ? !"), base[3])
            else -> base
        }
    }

    private fun weightOf(l: String) = when (l) {
        "SPACE" -> 4f
        "⇧", "⌫" -> 1.5f
        "↵" -> 1.7f
        "123", "ABC", "বাং", "EN", "অআ", "কখ" -> 1.4f
        "😊" -> 1.2f
        else -> 1f
    }

    private fun setMode(m: String) {
        mode = m
        if (m != "EN") shift = false
        word.setLength(0)
        suggestions = emptyList()
        keys = layoutFor(m).map { row ->
            row.map { label -> Key(label, weightOf(label)).apply { pos = 0.55f } }
        }
        layoutKeys()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(
            MeasureSpec.getSize(widthSpec),
            (inset + dp(236f) * heightScale + margin).toInt()
        )
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        panel.set(margin, inset, w - margin, h - margin)
        panelPath.reset()
        panelPath.addRoundRect(panel, panelRadius, panelRadius, Path.Direction.CW)
        bgPaint.shader = LinearGradient(
            0f, panel.top, 0f, panel.bottom,
            0xFF150827.toInt(), 0xFF05020D.toInt(), Shader.TileMode.CLAMP
        )
        computeBgSrc()
        layoutKeys()
    }

    private fun layoutKeys() {
        if (panel.width() <= 0f) return
        val emoji = mode == "EMOJI"
        val pad = dp(9f)
        val gap = dp(6f)
        val avail = panel.width() - 2 * pad
        val layoutRows = if (emoji) 4 else keys.size
        val rowH = (panel.height() - 2 * pad - gap * (layoutRows - 1)) / layoutRows
        val baseUnit = (avail - gap * 9) / 10
        if (emoji) {
            gridRect.set(
                panel.left + pad, panel.top + pad,
                panel.right - pad, panel.top + pad + 3 * (rowH + gap) - gap
            )
        }
        keys.forEachIndexed { r, row ->
            val n = row.size
            val sum = row.map { it.weight }.sum()
            val unit = min(baseUnit, (avail - gap * (n - 1)) / sum)
            val hasSpace = row.any { it.label == "SPACE" }
            val fixed = row.filter { it.label != "SPACE" }.map { it.weight }.sum()
            val spaceW = avail - fixed * unit - gap * (n - 1)
            val rowW = if (hasSpace) avail else sum * unit + gap * (n - 1)
            var x = panel.left + (panel.width() - rowW) / 2
            val top = if (emoji) panel.top + pad + 3 * (rowH + gap) else panel.top + pad + r * (rowH + gap)
            row.forEach { k ->
                val kw = if (k.label == "SPACE") spaceW else k.weight * unit
                k.rect.set(x, top, x + kw, top + rowH)
                x += kw + gap
                k.fill = LinearGradient(
                    0f, k.rect.top, 0f, k.rect.bottom,
                    0xFF241046.toInt(), 0xFF0B0418.toInt(), Shader.TileMode.CLAMP
                )
            }
        }
    }

    private fun displayLabel(k: Key): String {
        if (k.label == "SPACE") {
            return when (mode) { "EN" -> "English"; "NUM" -> ""; else -> "বাংলা" }
        }
        if (mode == "EN" && shift && k.label.length == 1 && k.label[0].isLetter()) {
            return k.label.uppercase()
        }
        if (k.label.length == 1) {
            val ty = Character.getType(k.label[0])
            if (ty == Character.NON_SPACING_MARK.toInt() || ty == Character.COMBINING_SPACING_MARK.toInt()) {
                return "\u25CC" + k.label
            }
        }
        return k.label
    }

    // ------------------------------------------------------------------ emoji data

    private fun gather(p: Paint, ranges: List<IntRange>, extras: List<String> = emptyList()): List<String> {
        val out = ArrayList<String>()
        for (r in ranges) for (cp in r) {
            val s = String(Character.toChars(cp))
            if (p.hasGlyph(s)) out.add(s)
        }
        for (s in extras) if (p.hasGlyph(s)) out.add(s)
        return out
    }

    private fun buildEmojis() {
        Thread {
            try {
                val p = Paint()
                val faces = gather(p,
                    listOf(0x1F600..0x1F644, 0x1F910..0x1F917, 0x1F920..0x1F925, 0x1F927..0x1F92F,
                        0x1F970..0x1F97A, 0x1F47B..0x1F47F, 0x1F4A9..0x1F4A9, 0x1F480..0x1F480,
                        0x1F9D0..0x1F9D0, 0x1FAE0..0x1FAE8),
                    listOf("\u263A\uFE0F", "\u2639\uFE0F", "\u2620\uFE0F"))
                val people = gather(p,
                    listOf(0x1F645..0x1F64F, 0x1F446..0x1F450, 0x1F466..0x1F487, 0x1F590..0x1F596,
                        0x1F918..0x1F91F, 0x1F930..0x1F93A, 0x1F440..0x1F445, 0x1F4AA..0x1F4AA,
                        0x1F9D1..0x1F9DF),
                    listOf("\u270C\uFE0F", "\u261D\uFE0F", "\u270D\uFE0F", "\u270B", "\u270A"))
                val nature = gather(p,
                    listOf(0x1F400..0x1F43F, 0x1F980..0x1F9AE, 0x1F330..0x1F335, 0x1F337..0x1F344,
                        0x1F490..0x1F490, 0x1F308..0x1F31F),
                    listOf("\u2600\uFE0F", "\u2601\uFE0F", "\u26A1", "\u2744\uFE0F", "\u2B50", "\u2728", "\u2618\uFE0F"))
                val food = gather(p,
                    listOf(0x1F345..0x1F37F, 0x1F950..0x1F96B, 0x1F9C0..0x1F9CB, 0x1F32D..0x1F32F),
                    listOf("\u2615"))
                val sport = gather(p,
                    listOf(0x1F380..0x1F393, 0x1F3A0..0x1F3CA, 0x1F94A..0x1F94F, 0x1F3CF..0x1F3D3,
                        0x1F93C..0x1F93E, 0x1F9E9..0x1F9E9),
                    listOf("\u26BD", "\u26BE", "\u26F3", "\u265F\uFE0F"))
                val travel = gather(p,
                    listOf(0x1F680..0x1F6C5, 0x1F3E0..0x1F3F0, 0x1F5FB..0x1F5FF, 0x1F30D..0x1F30F,
                        0x1F3D4..0x1F3DF, 0x1F6CB..0x1F6D2, 0x1F6D5..0x1F6D7, 0x1F6E0..0x1F6EC))
                val objects = gather(p,
                    listOf(0x1F4A1..0x1F4A1, 0x1F4B0..0x1F4FC, 0x1F50A..0x1F52E, 0x1F9E6..0x1F9FF,
                        0x1FA70..0x1FA7C, 0x1FA80..0x1FA88, 0x1FA90..0x1FAB6))
                val symbols = gather(p,
                    listOf(0x1F493..0x1F49F, 0x1F90D..0x1F90F, 0x1F9E1..0x1F9E1, 0x1F5A4..0x1F5A4,
                        0x1F4AF..0x1F4AF, 0x1F4A2..0x1F4AB, 0x1F500..0x1F53D, 0x1F7E0..0x1F7EB),
                    listOf("\u2764\uFE0F", "\u2763\uFE0F", "\u2705", "\u274C", "\u2757", "\u2753",
                        "\u203C\uFE0F", "\u2714\uFE0F", "\u2795", "\u2796", "\u2B06\uFE0F", "\u2B07\uFE0F",
                        "\u2B05\uFE0F", "\u27A1\uFE0F", "\u2660\uFE0F", "\u2665\uFE0F", "\u2666\uFE0F",
                        "\u2663\uFE0F", "\u00A9\uFE0F", "\u00AE\uFE0F", "\u2122\uFE0F"))
                val flags = ArrayList<String>(gather(p, listOf(0x1F3C1..0x1F3C1, 0x1F6A9..0x1F6A9, 0x1F38C..0x1F38C)))
                for (a in 0 until 26) for (b in 0 until 26) {
                    val s = String(Character.toChars(0x1F1E6 + a)) + String(Character.toChars(0x1F1E6 + b))
                    if (p.hasGlyph(s)) flags.add(s)
                }
                val result = listOf(faces, people, nature, food, sport, travel, objects, symbols, flags)
                Handler(Looper.getMainLooper()).post { emojiCats = result }
            } catch (e: Exception) {
                // emoji pages stay empty if the font check fails
            }
        }.start()
    }

    // ------------------------------------------------------------------ sound

    private fun makeClick(freq: Double): AudioTrack? {
        return try {
            val sr = 22050
            val n = (sr * 0.02).toInt()
            val data = ShortArray(n) { i ->
                val tt = i / sr.toDouble()
                (sin(2 * PI * freq * tt) * exp(-tt * 230.0) * 7000.0).toInt().toShort()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(data, 0, n)
            track
        } catch (e: Exception) {
            null
        }
    }

    private fun playClick(special: Boolean) {
        if (!soundOn) return
        if (clickA == null) {
            clickA = makeClick(1900.0)
            clickB = makeClick(1300.0)
        }
        val t = (if (special) clickB else clickA) ?: return
        try {
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
            // ignore sound errors
        }
    }

    // ------------------------------------------------------------------ drawing

    private fun neon(c: Canvas, r: RectF, rad: Float, color: Int, boost: Float, scale: Float) {
        for (i in 0..2) {
            glowPaint.strokeWidth = dp(glowW[i])
            glowPaint.color = withAlpha(color, (glowA[i] * boost * scale).toInt())
            c.drawRoundRect(r, rad, rad, glowPaint)
        }
        glowPaint.strokeWidth = dp(1.3f)
        glowPaint.color = withAlpha(mixWhite(color, 0.5f), (255 * scale).toInt())
        c.drawRoundRect(r, rad, rad, glowPaint)
    }

    private fun neonPath(c: Canvas, path: Path, color: Int, boost: Float, scale: Float) {
        for (i in 0..2) {
            glowPaint.strokeWidth = dp(glowW[i])
            glowPaint.color = withAlpha(color, (glowA[i] * boost * scale).toInt())
            c.drawPath(path, glowPaint)
        }
        glowPaint.strokeWidth = dp(1.3f)
        glowPaint.color = withAlpha(mixWhite(color, 0.5f), (255 * scale).toInt())
        c.drawPath(path, glowPaint)
    }

    private fun beginKey(c: Canvas, k: Key) {
        val r = k.rect
        c.save()
        c.translate(0f, dp(1.5f) * k.pos)
        c.scale(1f - 0.05f * k.pos, 1f - 0.12f * k.pos, r.centerX(), r.centerY())
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = min((now - last) / 1e9f, 0.032f)
        last = now
        timeSec = (now - start) / 1e9f
        val ip = if (introT0 == 0L) 2f else (now - introT0) / 1e9f / 0.9f
        val introOn = ip < 1f
        val ec = ip.coerceIn(0f, 1f)
        val sweepX = panel.left - dp(80f) + (panel.width() + dp(160f)) * (ec * ec * (3f - 2f * ec))

        // panel: dark gradient or the chosen photo
        val photo = bgBitmap
        if (photo != null && !bgSrc.isEmpty) {
            c.save()
            c.clipPath(panelPath)
            c.drawBitmap(photo, bgSrc, panel, photoPaint)
            tintPaint.color = 0x99060210.toInt()
            c.drawRect(panel, tintPaint)
            c.restore()
        } else {
            c.drawRoundRect(panel, panelRadius, panelRadius, bgPaint)
        }
        neon(c, panel, panelRadius, accentAt(panel.centerX(), panel.centerY()),
            0.9f + (if (introOn) 1.4f * (1f - ip) else 0f), 0.9f)

        for (row in keys) for (k in row) {
            if (introOn && !k.kicked && k.rect.centerX() <= sweepX) {
                k.kicked = true
                k.vel += 3.5f
            }
            val acc = -420f * (k.pos - k.target) - 16f * k.vel
            k.vel += acc * dt
            k.pos += k.vel * dt
            val bt = if (k.target == 1f || now < k.holdUntil) 1f else 0f
            val bAcc = -520f * (k.bub - bt) - 30f * k.bubVel
            k.bubVel += bAcc * dt
            k.bub += k.bubVel * dt
        }

        // pass 1: backlight leaking between the keycaps
        for (row in keys) for (k in row) {
            val r = k.rect
            val rad = r.height() * 0.18f
            val press = k.pos.coerceIn(0f, 1f)
            beginKey(c, k)
            val dd = (r.centerX() - sweepX) / dp(90f)
            val wave = if (introOn) exp(-dd * dd) else 0f
            val bc = accentAt(r.centerX(), r.centerY())
            tintPaint.color = withAlpha(mixWhite(bc, 0.2f), (150 + 70 * press + 60 * wave).toInt())
            val gi = dp(2.6f)
            tmp.set(r.left - gi, r.top - gi, r.right + gi, r.bottom + gi)
            c.drawRoundRect(tmp, rad + gi, rad + gi, tintPaint)
            neon(c, r, rad, bc, 1f + 0.9f * press + 1.8f * wave, 1f)
            c.restore()
        }

        // pass 2: keycaps and labels
        for (row in keys) for (k in row) drawKeyBody(c, k)

        if (mode == "EMOJI") drawGrid(c, dt)

        if (introOn) {
            c.save()
            c.clipPath(panelPath)
            val sc = accentAt(sweepX, panel.centerY())
            ripplePaint.shader = LinearGradient(
                sweepX - dp(70f), 0f, sweepX + dp(70f), 0f,
                intArrayOf(withAlpha(sc, 0), withAlpha(mixWhite(sc, 0.5f), (120 * (1f - ip * 0.5f)).toInt()), withAlpha(sc, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(panel, ripplePaint)
            c.restore()
        }

        c.save()
        c.clipPath(panelPath)
        val it = ripples.iterator()
        while (it.hasNext()) {
            val rp = it.next()
            val age = (now - rp.t0) / 1e9f / 0.6f
            if (age >= 1f) { it.remove(); continue }
            val radius = dp(18f) + dp(120f) * age
            val a = (110 * (1f - age)).toInt()
            ripplePaint.shader = RadialGradient(
                rp.x, rp.y, radius,
                intArrayOf(withAlpha(rp.color, a), withAlpha(rp.color, 0)),
                floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(rp.x, rp.y, radius, ripplePaint)
        }
        c.restore()

        drawSuggestions(c)
        for (row in keys) for (k in row) drawBubble(c, k)

        postInvalidateOnAnimation()
    }

    private fun drawKeyBody(c: Canvas, k: Key) {
        val r = k.rect
        val rad = r.height() * 0.18f
        val press = k.pos.coerceIn(0f, 1f)
        val color = accentAt(r.centerX(), r.centerY())
        beginKey(c, k)

        bodyPaint.shader = k.fill
        c.drawRoundRect(r, rad, rad, bodyPaint)

        var lit = 70 * press
        if (k.label == "⇧" && shift) lit = 90f
        if (k.label == "↵") lit = max(lit, 38f)
        if (mode == "EMOJI" && k.label == tabLabels[emojiTab]) lit = max(lit, 85f)
        if (lit > 0f) {
            tintPaint.color = withAlpha(color, lit.toInt())
            c.drawRoundRect(r, rad, rad, tintPaint)
        }

        val label = displayLabel(k)
        if (label.isNotEmpty()) {
            val glyph = k.label == "⇧" || k.label == "⌫" || k.label == "↵"
            val emo = k.label in tabLabels || k.label == "😊"
            val small = k.label == "SPACE" || (k.label in specials && !glyph && !emo)
            textPaint.textSize = when {
                emo -> dp(20f)
                glyph -> dp(22f)
                small -> dp(15f)
                else -> dp(21f)
            }
            textPaint.color = mixWhite(color, 0.45f)
            textPaint.alpha = if (k.label == "SPACE") 190 else 255
            textPaint.setShadowLayer(dp(6f) * (1f + press), 0f, 0f, color)
            val fm = textPaint.fontMetrics
            c.drawText(label, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, textPaint)
        }
        c.restore()
    }

    private fun maxScroll(): Float {
        val list = if (emojiCats.isNotEmpty()) emojiCats[emojiTab] else emptyList()
        val cell = gridRect.height() / 3f
        val cols = ceil(list.size / 3f)
        return max(0f, cols * cell - gridRect.width())
    }

    private fun drawGrid(c: Canvas, dt: Float) {
        val list = if (emojiCats.isNotEmpty()) emojiCats[emojiTab] else emptyList()
        val cell = gridRect.height() / 3f
        if (gridPointer == -1 && abs(flingV) > 20f) {
            gridScroll = (gridScroll + flingV * dt).coerceIn(0f, maxScroll())
            flingV *= exp(-dt * 3.2f)
        }
        textPaint.clearShadowLayer()
        textPaint.alpha = 255
        textPaint.color = Color.WHITE
        c.save()
        c.clipRect(gridRect)
        if (list.isEmpty()) {
            textPaint.textSize = dp(14f)
            c.drawText("...", gridRect.centerX(), gridRect.centerY(), textPaint)
        } else {
            textPaint.textSize = cell * 0.58f
            val fm = textPaint.fontMetrics
            val first = max(0, floor(gridScroll / cell).toInt())
            val lastCol = floor((gridScroll + gridRect.width()) / cell).toInt()
            for (col in first..lastCol) for (row in 0..2) {
                val idx = col * 3 + row
                if (idx >= list.size) continue
                val x = gridRect.left + col * cell - gridScroll + cell / 2
                val y = gridRect.top + row * cell + cell / 2
                c.drawText(list[idx], x, y - (fm.ascent + fm.descent) / 2f, textPaint)
            }
        }
        c.restore()
    }

    private fun drawSuggestions(c: Canvas) {
        if (suggestions.isEmpty() || mode == "EMOJI") return
        val top = dp(6f)
        val bottom = inset - dp(6f)
        val left = margin + dp(2f)
        val right = width - margin - dp(2f)
        tmp.set(left, top, right, bottom)
        val rad = (bottom - top) / 2f
        tintPaint.color = 0xEE0B0418.toInt()
        c.drawRoundRect(tmp, rad, rad, tintPaint)
        val color = accentAt(width / 2f, top)
        neon(c, tmp, rad, color, 0.5f, 0.7f)
        textPaint.clearShadowLayer()
        textPaint.alpha = 255
        textPaint.color = mixWhite(color, 0.55f)
        textPaint.textSize = dp(17f)
        val fm = textPaint.fontMetrics
        val slotW = (right - left) / 3f
        for (i in suggestions.indices) {
            val cx = left + slotW * i + slotW / 2
            c.drawText(suggestions[i], cx, (top + bottom) / 2 - (fm.ascent + fm.descent) / 2f, textPaint)
            if (i > 0) {
                tintPaint.color = withAlpha(color, 90)
                c.drawRect(left + slotW * i - dp(0.5f), top + dp(8f), left + slotW * i + dp(0.5f), bottom - dp(8f), tintPaint)
            }
        }
    }

    /** Smooth neon bubble that grows out of the pressed key. */
    private fun drawBubble(c: Canvas, k: Key) {
        if (k.label in specials || k.label == "SPACE") return
        val raw = k.bub.coerceIn(0f, 1f)
        if (raw < 0.03f) return
        val p = (raw * 2.5f).coerceAtMost(1f)
        val r = k.rect
        val bw = r.width() * 1.6f
        var bl = r.centerX() - bw / 2
        bl = bl.coerceIn(dp(3f), width - dp(3f) - bw)
        val br = bl + bw
        val bt = r.top - dp(40f)
        val wy = r.top - dp(8f)
        val ny = r.top + dp(5f)
        val kl = r.left
        val kr = r.right
        val rad = dp(15f)
        val kc = r.height() * 0.18f
        val color = accentAt(r.centerX(), r.centerY())

        val path = bubblePath
        path.reset()
        path.moveTo(kl + kc, r.bottom)
        path.lineTo(kr - kc, r.bottom)
        path.quadTo(kr, r.bottom, kr, r.bottom - kc)
        path.lineTo(kr, ny)
        path.cubicTo(kr, ny - dp(12f), br, wy + dp(12f), br, wy)
        path.lineTo(br, bt + rad)
        path.quadTo(br, bt, br - rad, bt)
        path.lineTo(bl + rad, bt)
        path.quadTo(bl, bt, bl, bt + rad)
        path.lineTo(bl, wy)
        path.cubicTo(bl, wy + dp(12f), kl, ny - dp(12f), kl, ny)
        path.lineTo(kl, r.bottom - kc)
        path.quadTo(kl, r.bottom, kl + kc, r.bottom)
        path.close()

        val sc = 0.72f + 0.28f * k.bub.coerceAtLeast(0f)
        c.save()
        c.scale(sc, sc, r.centerX(), r.bottom)

        shadowPaint.alpha = (110 * p).toInt()
        c.save()
        c.translate(0f, dp(3f))
        c.drawPath(path, shadowPaint)
        c.restore()
        shadowPaint.alpha = 0x66

        bodyPaint.shader = LinearGradient(
            0f, bt, 0f, r.bottom, 0xFF3F1D78.toInt(), 0xFF170830.toInt(), Shader.TileMode.CLAMP
        )
        bodyPaint.alpha = (255 * p).toInt()
        c.drawPath(path, bodyPaint)
        bodyPaint.alpha = 255

        tintPaint.color = withAlpha(0xFFFFFFFF.toInt(), (28 * p).toInt())
        tmp.set(bl + dp(7f), bt + dp(4f), br - dp(7f), bt + (wy - bt) * 0.45f)
        c.drawRoundRect(tmp, dp(9f), dp(9f), tintPaint)

        neonPath(c, path, color, 1.3f, p)

        textPaint.textSize = dp(34f)
        textPaint.color = mixWhite(color, 0.6f)
        textPaint.alpha = (255 * p).toInt()
        textPaint.setShadowLayer(dp(8f), 0f, 0f, color)
        val fm = textPaint.fontMetrics
        c.drawText(displayLabel(k), (bl + br) / 2, (bt + wy) / 2 - (fm.ascent + fm.descent) / 2f, textPaint)
        c.restore()
    }

    // ------------------------------------------------------------------ input

    private fun keyAt(x: Float, y: Float): Key? {
        val g = dp(3f)
        for (row in keys) for (k in row) {
            val r = k.rect
            if (x >= r.left - g && x <= r.right + g && y >= r.top - g && y <= r.bottom + g) return k
        }
        return null
    }

    private fun updateSuggestions() {
        suggestions = if (mode == "EN") Words.suggest(word.toString()) else emptyList()
    }

    private fun fire(k: Key) {
        if (k.label in tabLabels) {
            emojiTab = tabLabels.indexOf(k.label)
            gridScroll = 0f
            flingV = 0f
            return
        }
        when (k.label) {
            "⇧" -> shift = !shift
            "⌫" -> {
                listener?.onBackspace()
                if (word.isNotEmpty()) word.deleteCharAt(word.length - 1)
                updateSuggestions()
            }
            "↵" -> { listener?.onEnter(); resetWord() }
            "SPACE" -> { listener?.onText(" "); resetWord() }
            "123" -> setMode("NUM")
            "ABC", "EN" -> setMode("EN")
            "বাং", "কখ" -> setMode("BN1")
            "অআ" -> setMode("BN2")
            "😊" -> setMode("EMOJI")
            else -> {
                val text = if (mode == "EN" && shift) k.label.uppercase() else k.label
                listener?.onText(text)
                if (mode == "EN" && k.label.length == 1 && k.label[0].isLetter()) {
                    word.append(text)
                } else {
                    word.setLength(0)
                }
                updateSuggestions()
                if (shift) shift = false
            }
        }
    }

    private fun press(k: Key, x: Float, y: Float) {
        for (row in keys) {
            if (!row.contains(k)) continue
            for (o in row) {
                if (o === k) continue
                val d = abs(o.rect.centerX() - k.rect.centerX())
                val reach = k.rect.width() * 2.6f
                if (d < reach) o.vel += 3.2f * (1f - d / reach)
            }
        }
        k.target = 1f
        k.holdUntil = System.nanoTime() + 140_000_000L
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        playClick(k.label in specials || k.label == "SPACE")
        ripples.add(Ripple(x, y, System.nanoTime(), accentAt(x, y)))
        fire(k)
        if (k.label == "⌫") {
            repeatKey = k
            handler.postDelayed(repeatRunnable, 380)
        }
    }

    private fun release(k: Key) {
        k.target = 0f
        if (k === repeatKey) {
            repeatKey = null
            handler.removeCallbacks(repeatRunnable)
        }
    }

    private fun tapStrip(x: Float) {
        if (suggestions.isEmpty() || mode == "EMOJI") return
        val left = margin + dp(2f)
        val slotW = (width - margin - dp(2f) - left) / 3f
        val i = ((x - left) / slotW).toInt()
        if (i in suggestions.indices) {
            listener?.onReplace(word.toString(), suggestions[i])
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            playClick(false)
            resetWord()
        }
    }

    private fun tapGrid(x: Float, y: Float) {
        val list = if (emojiCats.isNotEmpty()) emojiCats[emojiTab] else return
        val cell = gridRect.height() / 3f
        val col = floor((x - gridRect.left + gridScroll) / cell).toInt()
        val row = floor((y - gridRect.top) / cell).toInt()
        val idx = col * 3 + row
        if (col >= 0 && row in 0..2 && idx in list.indices) {
            listener?.onText(list[idx])
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            playClick(false)
            ripples.add(Ripple(x, y, System.nanoTime(), accentAt(x, y)))
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val x = e.getX(i)
                val y = e.getY(i)
                if (y < inset) {
                    tapStrip(x)
                } else if (mode == "EMOJI" && gridRect.contains(x, y)) {
                    gridPointer = e.getPointerId(i)
                    gridDownX = x
                    gridDownY = y
                    gridLastX = x
                    gridMoved = false
                    flingV = 0f
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(e)
                } else {
                    val k = keyAt(x, y)
                    if (k != null) {
                        active[e.getPointerId(i)] = k
                        press(k, x, y)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (gridPointer != -1) {
                    val idx = e.findPointerIndex(gridPointer)
                    if (idx >= 0) {
                        val x = e.getX(idx)
                        vt?.addMovement(e)
                        if (!gridMoved && abs(x - gridDownX) > touchSlop) gridMoved = true
                        if (gridMoved) gridScroll = (gridScroll - (x - gridLastX)).coerceIn(0f, maxScroll())
                        gridLastX = x
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val pid = e.getPointerId(e.actionIndex)
                if (pid == gridPointer) {
                    gridPointer = -1
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    flingV = if (gridMoved) -(vt?.xVelocity ?: 0f) else 0f
                    vt?.recycle()
                    vt = null
                    if (!gridMoved) tapGrid(gridDownX, gridDownY)
                } else {
                    active.remove(pid)?.let { release(it) }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                gridPointer = -1
                vt?.recycle()
                vt = null
                active.values.forEach { release(it) }
                active.clear()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatRunnable)
        try { clickA?.release(); clickB?.release() } catch (e: Exception) { }
        clickA = null
        clickB = null
        super.onDetachedFromWindow()
    }
}
