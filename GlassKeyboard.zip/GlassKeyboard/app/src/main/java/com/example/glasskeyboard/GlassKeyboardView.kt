package com.example.glasskeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Liquid Glass keyboard: translucent glass keys, jelly spring animation, ripples. */
class GlassKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onBackspace()
        fun onEnter()
    }

    var listener: Listener? = null

    private class Key(val label: String, val weight: Float) {
        val rect = RectF()
        var pos = 0f      // spring position: 0 = rest, 1 = fully pressed
        var vel = 0f
        var target = 0f
        var fill: Shader? = null
        var rim: Shader? = null
        var spec: Shader? = null
    }

    private class Ripple(val x: Float, val y: Float, val t0: Long)

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun w(str: String) = str.split(" ")

    private val specials = setOf("⇧", "⌫", "↵", "123", "ABC", "বাং", "EN", "অআ", "কখ")

    private val layouts: Map<String, List<List<String>>> = mapOf(
        "EN" to listOf(
            w("q w e r t y u i o p"),
            w("a s d f g h j k l"),
            w("⇧ z x c v b n m ⌫"),
            w("123 বাং , SPACE . ↵")
        ),
        "BN1" to listOf(
            w("ক খ গ ঘ ঙ চ ছ জ ঝ ঞ"),
            w("ট ঠ ড ঢ ণ ত থ দ ধ ন"),
            w("প ফ ব ভ ম য র ল শ ⌫"),
            w("অআ EN SPACE । ↵")
        ),
        "BN2" to listOf(
            w("অ আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ"),
            w("া ি ী ু ূ ৃ ে ৈ ো ৌ"),
            w("ষ স হ ড\u09BC ঢ\u09BC য\u09BC ৎ ং ঃ ঁ"),
            w("কখ ্ SPACE ⌫ ↵")
        ),
        "NUM" to listOf(
            w("1 2 3 4 5 6 7 8 9 0"),
            w("১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯ ০"),
            w("@ # ৳ & - + ( ) ? !"),
            w("ABC , SPACE . ⌫ ↵")
        )
    )

    private var mode = "EN"
    private var shift = false
    private var keys: List<List<Key>> = emptyList()
    private val ripples = mutableListOf<Ripple>()

    private val start = System.nanoTime()
    private var last = start

    private val bgPaint = Paint()
    private val blobPaints = Array(3) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val specPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.4f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        setShadowLayer(dp(3f), 0f, dp(1f), 0x55000000)
    }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmp = RectF()

    private val active = HashMap<Int, Key>()
    private val handler = Handler(Looper.getMainLooper())
    private var repeatKey: Key? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            if (repeatKey != null) {
                listener?.onBackspace()
                handler.postDelayed(this, 45)
            }
        }
    }

    init {
        setMode("EN")
    }

    private fun weightOf(l: String) = when (l) {
        "SPACE" -> 4f
        "⇧", "⌫" -> 1.5f
        "↵" -> 1.7f
        "123", "ABC", "বাং", "EN", "অআ", "কখ" -> 1.4f
        else -> 1f
    }

    private fun setMode(m: String) {
        mode = m
        if (m != "EN") shift = false
        keys = layouts.getValue(m).map { row ->
            row.map { label -> Key(label, weightOf(label)).apply { pos = 0.55f } }
        }
        layoutKeys()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthSpec), dp(240f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bgPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0xFF1A1055.toInt(), 0xFF0B3B6B.toInt(), 0xFF4A1A6B.toInt()),
            null, Shader.TileMode.CLAMP
        )
        val colors = intArrayOf(0xFFFF4D8D.toInt(), 0xFF12C2E9.toInt(), 0xFFFFB02E.toInt())
        val rad = h * 1.1f
        for (i in 0..2) {
            val rgb = colors[i] and 0x00FFFFFF
            blobPaints[i].shader = RadialGradient(
                0f, 0f, rad, rgb or 0x99000000.toInt(), rgb, Shader.TileMode.CLAMP
            )
        }
        layoutKeys()
    }

    private fun layoutKeys() {
        if (width == 0 || height == 0) return
        val pad = dp(6f)
        val gap = dp(6f)
        val avail = width - 2 * pad
        val rows = keys.size
        val rowH = (height - 2 * pad - gap * (rows - 1)) / rows
        val baseUnit = (avail - gap * 9) / 10
        keys.forEachIndexed { r, row ->
            val n = row.size
            val sum = row.map { it.weight }.sum()
            val unit = min(baseUnit, (avail - gap * (n - 1)) / sum)
            val hasSpace = row.any { it.label == "SPACE" }
            val fixed = row.filter { it.label != "SPACE" }.map { it.weight }.sum()
            val spaceW = avail - fixed * unit - gap * (n - 1)
            val rowW = if (hasSpace) avail else sum * unit + gap * (n - 1)
            var x = (width - rowW) / 2
            val top = pad + r * (rowH + gap)
            row.forEach { k ->
                val kw = if (k.label == "SPACE") spaceW else k.weight * unit
                k.rect.set(x, top, x + kw, top + rowH)
                x += kw + gap
                buildShaders(k)
            }
        }
    }

    private fun buildShaders(k: Key) {
        val r = k.rect
        val topC: Int
        val botC: Int
        when {
            k.label == "↵" -> { topC = 0x99669BFF.toInt(); botC = 0x55669BFF }
            k.label in specials -> { topC = 0x55A6C8FF; botC = 0x22A6C8FF }
            else -> { topC = 0x70FFFFFF; botC = 0x26FFFFFF }
        }
        k.fill = LinearGradient(r.left, r.top, r.left, r.bottom, topC, botC, Shader.TileMode.CLAMP)
        k.rim = LinearGradient(
            r.left, r.top, r.right, r.bottom,
            intArrayOf(0xF2FFFFFF.toInt(), 0x10FFFFFF, 0x10FFFFFF, 0xB0FFFFFF.toInt()),
            floatArrayOf(0f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        k.spec = LinearGradient(
            r.left, r.top, r.left, r.top + r.height() * 0.5f,
            0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
    }

    private fun displayLabel(k: Key): String {
        if (k.label == "SPACE") {
            return when (mode) { "EN" -> "English"; "NUM" -> ""; else -> "বাংলা" }
        }
        if (mode == "EN" && shift && k.label.length == 1 && k.label[0].isLetter()) {
            return k.label.uppercase()
        }
        if (k.label.length == 1) {
            val ty = Character.getType(k.label[0])
            if (ty == Character.NON_SPACING_MARK.toInt() || ty == Character.COMBINING_SPACING_MARK.toInt()) {
                return "\u25CC" + k.label
            }
        }
        return k.label
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = min((now - last) / 1e9f, 0.032f)
        last = now
        val t = (now - start) / 1e9f
        val wf = width.toFloat()
        val hf = height.toFloat()

        c.drawRect(0f, 0f, wf, hf, bgPaint)
        for (i in 0..2) {
            val bx = wf * (0.5f + 0.45f * sin(t * 0.5f + i * 2.1f))
            val by = hf * (0.5f + 0.35f * cos(t * 0.4f + i * 1.7f))
            c.save()
            c.translate(bx, by)
            c.drawCircle(0f, 0f, hf * 1.1f, blobPaints[i])
            c.restore()
        }

        for (row in keys) for (k in row) {
            val acc = -420f * (k.pos - k.target) - 16f * k.vel
            k.vel += acc * dt
            k.pos += k.vel * dt
            drawKey(c, k)
        }

        val it = ripples.iterator()
        while (it.hasNext()) {
            val rp = it.next()
            val age = (now - rp.t0) / 1e9f / 0.55f
            if (age >= 1f) { it.remove(); continue }
            val radius = dp(20f) + dp(110f) * age
            val a = (120 * (1f - age)).toInt()
            ripplePaint.shader = RadialGradient(
                rp.x, rp.y, radius,
                intArrayOf(Color.argb(a, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(rp.x, rp.y, radius, ripplePaint)
        }

        postInvalidateOnAnimation()
    }

    private fun drawKey(c: Canvas, k: Key) {
        val r = k.rect
        val cx = r.centerX()
        val cy = r.centerY()
        val press = k.pos.coerceIn(0f, 1f)
        val sx = 1f - 0.06f * k.pos
        val sy = 1f - 0.15f * k.pos
        val rad = r.height() * 0.36f

        c.save()
        c.translate(0f, dp(2f) * k.pos)
        c.scale(sx, sy, cx, cy)

        c.drawRoundRect(r.left, r.top + dp(2.5f), r.right, r.bottom + dp(2.5f), rad, rad, shadowPaint)

        fillPaint.shader = k.fill
        c.drawRoundRect(r, rad, rad, fillPaint)

        var glow = 85 * press
        if (k.label == "⇧" && shift) glow = 100f
        if (glow > 0f) {
            glowPaint.color = Color.argb(glow.toInt(), 255, 255, 255)
            c.drawRoundRect(r, rad, rad, glowPaint)
        }

        specPaint.shader = k.spec
        tmp.set(r.left + dp(6f), r.top + dp(2.5f), r.right - dp(6f), r.top + r.height() * 0.5f)
        c.drawRoundRect(tmp, rad * 0.8f, rad * 0.8f, specPaint)

        rimPaint.shader = k.rim
        val h = rimPaint.strokeWidth / 2
        tmp.set(r.left + h, r.top + h, r.right - h, r.bottom - h)
        c.drawRoundRect(tmp, rad, rad, rimPaint)

        val label = displayLabel(k)
        if (label.isNotEmpty()) {
            val glyph = k.label == "⇧" || k.label == "⌫" || k.label == "↵"
            val small = k.label == "SPACE" || (k.label in specials && !glyph)
            textPaint.textSize = when {
                glyph -> dp(22f)
                small -> dp(15f)
                else -> dp(21f)
            }
            textPaint.alpha = if (k.label == "SPACE") 170 else 255
            val fm = textPaint.fontMetrics
            c.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
        }
        c.restore()
    }

    private fun keyAt(x: Float, y: Float): Key? {
        val g = dp(3f)
        for (row in keys) for (k in row) {
            val r = k.rect
            if (x >= r.left - g && x <= r.right + g && y >= r.top - g && y <= r.bottom + g) return k
        }
        return null
    }

    private fun fire(k: Key) {
        when (k.label) {
            "⇧" -> shift = !shift
            "⌫" -> listener?.onBackspace()
            "↵" -> listener?.onEnter()
            "SPACE" -> listener?.onText(" ")
            "123" -> setMode("NUM")
            "ABC", "EN" -> setMode("EN")
            "বাং", "কখ" -> setMode("BN1")
            "অআ" -> setMode("BN2")
            else -> {
                val text = if (mode == "EN" && shift) k.label.uppercase() else k.label
                listener?.onText(text)
                if (shift) shift = false
            }
        }
    }

    private fun press(k: Key, x: Float, y: Float) {
        k.target = 1f
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        ripples.add(Ripple(x, y, System.nanoTime()))
        fire(k)
        if (k.label == "⌫") {
            repeatKey = k
            handler.postDelayed(repeatRunnable, 380)
        }
    }

    private fun release(k: Key) {
        k.target = 0f
        if (k === repeatKey) {
            repeatKey = null
            handler.removeCallbacks(repeatRunnable)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val k = keyAt(e.getX(i), e.getY(i))
                if (k != null) {
                    active[e.getPointerId(i)] = k
                    press(k, e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                active.remove(e.getPointerId(i))?.let { release(it) }
            }
            MotionEvent.ACTION_CANCEL -> {
                active.values.forEach { release(it) }
                active.clear()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatRunnable)
        super.onDetachedFromWindow()
    }
}
