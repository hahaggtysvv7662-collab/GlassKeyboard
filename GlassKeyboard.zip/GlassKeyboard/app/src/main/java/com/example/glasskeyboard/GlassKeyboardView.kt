package com.example.glasskeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/** Neon RGB keyboard: dark keycaps, glowing edges, jelly spring, light waves. */
class GlassKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onBackspace()
        fun onEnter()
    }

    var listener: Listener? = null

    private class Key(val label: String, val weight: Float) {
        val rect = RectF()
        var pos = 0f
        var vel = 0f
        var target = 0f
        var bub = 0f
        var bubVel = 0f
        var kicked = true
        var holdUntil = 0L
        var fill: Shader? = null
    }

    private class Ripple(val x: Float, val y: Float, val t0: Long, val color: Int)

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun w(str: String) = str.split(" ")

    private val specials = setOf("⇧", "⌫", "↵", "123", "ABC", "বাং", "EN", "অআ", "কখ")

    private val layouts: Map<String, List<List<String>>> = mapOf(
        "EN" to listOf(
            w("q w e r t y u i o p"),
            w("a s d f g h j k l"),
            w("⇧ z x c v b n m ⌫"),
            w("123 বাং , SPACE . ↵")
        ),
        "BN1" to listOf(
            w("ক খ গ ঘ ঙ চ ছ জ ঝ ঞ"),
            w("ট ঠ ড ঢ ণ ত থ দ ধ ন"),
            w("প ফ ব ভ ম য র ল শ ⌫"),
            w("অআ EN SPACE । ↵")
        ),
        "BN2" to listOf(
            w("অ আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ"),
            w("া ি ী ু ূ ৃ ে ৈ ো ৌ"),
            w("ষ স হ ড\u09BC ঢ\u09BC য\u09BC ৎ ং ঃ ঁ"),
            w("কখ ্ SPACE ⌫ ↵")
        ),
        "NUM" to listOf(
            w("1 2 3 4 5 6 7 8 9 0"),
            w("১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯ ০"),
            w("@ # ৳ & - + ( ) ? !"),
            w("ABC , SPACE . ⌫ ↵")
        )
    )

    // accent colours: 0 purple, 1 blue, 2 pink, 3 green, 4 RGB cycling
    private val accents = intArrayOf(0xFFB026FF.toInt(), 0xFF2D9CFF.toInt(), 0xFFFF2D95.toInt(), 0xFF2DFF8A.toInt())
    private var accentIndex = 0
    private val hsv = FloatArray(3)

    fun setAccent(i: Int) {
        accentIndex = i.coerceIn(0, 4)
    }

    private var introT0 = 0L

    /** Light sweep across the keyboard when it opens (tap on a text field). */
    fun playIntro() {
        introT0 = System.nanoTime()
        keys.forEach { row -> row.forEach { it.kicked = false } }
    }

    private var mode = "EN"
    private var shift = false
    private var keys: List<List<Key>> = emptyList()
    private val ripples = mutableListOf<Ripple>()

    private val start = System.nanoTime()
    private var last = start
    private var timeSec = 0f

    private val inset = dp(46f)
    private val margin = dp(6f)
    private val panelRadius = dp(22f)
    private val panel = RectF()
    private val panelPath = Path()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
    private val tmp = RectF()

    private val glowW = floatArrayOf(9f, 5.5f, 2.6f)
    private val glowA = intArrayOf(45, 85, 150)

    private val active = HashMap<Int, Key>()
    private val handler = Handler(Looper.getMainLooper())
    private var repeatKey: Key? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            if (repeatKey != null) {
                listener?.onBackspace()
                handler.postDelayed(this, 45)
            }
        }
    }

    init {
        setMode("EN")
    }

    private fun withAlpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun mixWhite(color: Int, f: Float): Int {
        val r = ((color shr 16 and 0xFF) + (255 - (color shr 16 and 0xFF)) * f).toInt()
        val g = ((color shr 8 and 0xFF) + (255 - (color shr 8 and 0xFF)) * f).toInt()
        val b = ((color and 0xFF) + (255 - (color and 0xFF)) * f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun accentAt(x: Float, y: Float): Int {
        if (accentIndex < 4) return accents[accentIndex]
        hsv[0] = (timeSec * 70f + x / (if (width > 0) width else 1) * 220f + y * 0.15f) % 360f
        hsv[1] = 0.85f
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun weightOf(l: String) = when (l) {
        "SPACE" -> 4f
        "⇧", "⌫" -> 1.5f
        "↵" -> 1.7f
        "123", "ABC", "বাং", "EN", "অআ", "কখ" -> 1.4f
        else -> 1f
    }

    private fun setMode(m: String) {
        mode = m
        if (m != "EN") shift = false
        keys = layouts.getValue(m).map { row ->
            row.map { label -> Key(label, weightOf(label)).apply { pos = 0.55f } }
        }
        layoutKeys()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(
            MeasureSpec.getSize(widthSpec),
            (inset + dp(236f) + margin).toInt()
        )
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        panel.set(margin, inset, w - margin, h - margin)
        panelPath.reset()
        panelPath.addRoundRect(panel, panelRadius, panelRadius, Path.Direction.CW)
        bgPaint.shader = LinearGradient(
            0f, panel.top, 0f, panel.bottom,
            0xFF150827.toInt(), 0xFF05020D.toInt(), Shader.TileMode.CLAMP
        )
        layoutKeys()
    }

    private fun layoutKeys() {
        if (panel.width() <= 0f) return
        val pad = dp(9f)
        val gap = dp(6f)
        val avail = panel.width() - 2 * pad
        val rows = keys.size
        val rowH = (panel.height() - 2 * pad - gap * (rows - 1)) / rows
        val baseUnit = (avail - gap * 9) / 10
        keys.forEachIndexed { r, row ->
            val n = row.size
            val sum = row.map { it.weight }.sum()
            val unit = min(baseUnit, (avail - gap * (n - 1)) / sum)
            val hasSpace = row.any { it.label == "SPACE" }
            val fixed = row.filter { it.label != "SPACE" }.map { it.weight }.sum()
            val spaceW = avail - fixed * unit - gap * (n - 1)
            val rowW = if (hasSpace) avail else sum * unit + gap * (n - 1)
            var x = panel.left + (panel.width() - rowW) / 2
            val top = panel.top + pad + r * (rowH + gap)
            row.forEach { k ->
                val kw = if (k.label == "SPACE") spaceW else k.weight * unit
                k.rect.set(x, top, x + kw, top + rowH)
                x += kw + gap
                k.fill = LinearGradient(
                    0f, k.rect.top, 0f, k.rect.bottom,
                    0xFF241046.toInt(), 0xFF0B0418.toInt(), Shader.TileMode.CLAMP
                )
            }
        }
    }

    private fun displayLabel(k: Key): String {
        if (k.label == "SPACE") {
            return when (mode) { "EN" -> "English"; "NUM" -> ""; else -> "বাংলা" }
        }
        if (mode == "EN" && shift && k.label.length == 1 && k.label[0].isLetter()) {
            return k.label.uppercase()
        }
        if (k.label.length == 1) {
            val ty = Character.getType(k.label[0])
            if (ty == Character.NON_SPACING_MARK.toInt() || ty == Character.COMBINING_SPACING_MARK.toInt()) {
                return "\u25CC" + k.label
            }
        }
        return k.label
    }

    /** Neon outline: soft halo passes plus a bright core line. */
    private fun neon(c: Canvas, r: RectF, rad: Float, color: Int, boost: Float, scale: Float) {
        for (i in 0..2) {
            glowPaint.strokeWidth = dp(glowW[i])
            glowPaint.color = withAlpha(color, (glowA[i] * boost * scale).toInt())
            c.drawRoundRect(r, rad, rad, glowPaint)
        }
        glowPaint.strokeWidth = dp(1.3f)
        glowPaint.color = withAlpha(mixWhite(color, 0.5f), (255 * scale).toInt())
        c.drawRoundRect(r, rad, rad, glowPaint)
    }

    private fun beginKey(c: Canvas, k: Key) {
        val r = k.rect
        c.save()
        c.translate(0f, dp(1.5f) * k.pos)
        c.scale(1f - 0.05f * k.pos, 1f - 0.12f * k.pos, r.centerX(), r.centerY())
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = min((now - last) / 1e9f, 0.032f)
        last = now
        timeSec = (now - start) / 1e9f
        val ip = if (introT0 == 0L) 2f else (now - introT0) / 1e9f / 0.9f
        val introOn = ip < 1f
        val ec = ip.coerceIn(0f, 1f)
        val sweepX = panel.left - dp(80f) + (panel.width() + dp(160f)) * (ec * ec * (3f - 2f * ec))

        // dark panel with a neon edge
        c.drawRoundRect(panel, panelRadius, panelRadius, bgPaint)
        neon(c, panel, panelRadius, accentAt(panel.centerX(), panel.centerY()), 0.9f + (if (introOn) 1.4f * (1f - ip) else 0f), 0.9f)

        for (row in keys) for (k in row) {
            if (introOn && !k.kicked && k.rect.centerX() <= sweepX) {
                k.kicked = true
                k.vel += 3.5f
            }
            val acc = -420f * (k.pos - k.target) - 16f * k.vel
            k.vel += acc * dt
            k.pos += k.vel * dt
            val bt = if (k.target == 1f || now < k.holdUntil) 1f else 0f
            val bAcc = -520f * (k.bub - bt) - 30f * k.bubVel
            k.bubVel += bAcc * dt
            k.bub += k.bubVel * dt
        }

        // pass 1: glow in the gaps (light leaking around the keycaps)
        for (row in keys) for (k in row) {
            val r = k.rect
            val rad = r.height() * 0.18f
            val press = k.pos.coerceIn(0f, 1f)
            beginKey(c, k)
            val dd = (r.centerX() - sweepX) / dp(90f)
            val wave = if (introOn) exp(-dd * dd) else 0f
            val bc = accentAt(r.centerX(), r.centerY())
            tintPaint.color = withAlpha(mixWhite(bc, 0.2f), (150 + 70 * press + 60 * wave).toInt())
            val gi = dp(2.6f)
            tmp.set(r.left - gi, r.top - gi, r.right + gi, r.bottom + gi)
            c.drawRoundRect(tmp, rad + gi, rad + gi, tintPaint)
            neon(c, r, rad, bc, 1f + 0.9f * press + 1.8f * wave, 1f)
            c.restore()
        }

        // pass 2: dark keycaps and neon labels
        for (row in keys) for (k in row) {
            val r = k.rect
            val rad = r.height() * 0.18f
            val press = k.pos.coerceIn(0f, 1f)
            val color = accentAt(r.centerX(), r.centerY())
            beginKey(c, k)

            bodyPaint.shader = k.fill
            c.drawRoundRect(r, rad, rad, bodyPaint)

            var lit = 70 * press
            if (k.label == "⇧" && shift) lit = 90f
            if (k.label == "↵") lit = maxOf(lit, 38f)
            if (lit > 0f) {
                tintPaint.color = withAlpha(color, lit.toInt())
                c.drawRoundRect(r, rad, rad, tintPaint)
            }

            val label = displayLabel(k)
            if (label.isNotEmpty()) {
                val glyph = k.label == "⇧" || k.label == "⌫" || k.label == "↵"
                val small = k.label == "SPACE" || (k.label in specials && !glyph)
                textPaint.textSize = when {
                    glyph -> dp(22f)
                    small -> dp(15f)
                    else -> dp(21f)
                }
                textPaint.color = mixWhite(color, 0.45f)
                textPaint.alpha = if (k.label == "SPACE") 190 else 255
                textPaint.setShadowLayer(dp(6f) * (1f + press), 0f, 0f, color)
                val fm = textPaint.fontMetrics
                c.drawText(label, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, textPaint)
            }
            c.restore()
        }

        if (introOn) {
            c.save()
            c.clipPath(panelPath)
            val sc = accentAt(sweepX, panel.centerY())
            ripplePaint.shader = LinearGradient(
                sweepX - dp(70f), 0f, sweepX + dp(70f), 0f,
                intArrayOf(withAlpha(sc, 0), withAlpha(mixWhite(sc, 0.5f), (120 * (1f - ip * 0.5f)).toInt()), withAlpha(sc, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(panel, ripplePaint)
            c.restore()
        }

        // light ripples
        c.save()
        c.clipPath(panelPath)
        val it = ripples.iterator()
        while (it.hasNext()) {
            val rp = it.next()
            val age = (now - rp.t0) / 1e9f / 0.6f
            if (age >= 1f) { it.remove(); continue }
            val radius = dp(18f) + dp(120f) * age
            val a = (110 * (1f - age)).toInt()
            ripplePaint.shader = RadialGradient(
                rp.x, rp.y, radius,
                intArrayOf(withAlpha(rp.color, a), withAlpha(rp.color, 0)),
                floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(rp.x, rp.y, radius, ripplePaint)
        }
        c.restore()

        for (row in keys) for (k in row) drawBubble(c, k)

        postInvalidateOnAnimation()
    }

    /** Neon bubble that pops above a pressed letter. */
    private fun drawBubble(c: Canvas, k: Key) {
        if (k.label in specials || k.label == "SPACE") return
        val raw = k.bub.coerceIn(0f, 1f)
        if (raw < 0.03f) return
        val p = (raw * 2.5f).coerceAtMost(1f)
        val r = k.rect
        val bw = r.width() * 1.5f
        val bh = r.height() + dp(38f)
        var l = r.centerX() - bw / 2
        l = l.coerceIn(dp(3f), width - dp(3f) - bw)
        val b = RectF(l, r.bottom - bh, l + bw, r.bottom)
        val sc = 0.72f + 0.28f * k.bub.coerceAtLeast(0f)
        val rad = dp(10f)
        val color = accentAt(r.centerX(), r.centerY())

        c.save()
        c.scale(sc, sc, b.centerX(), b.bottom)
        c.drawRoundRect(b.left, b.top + dp(3f), b.right, b.bottom + dp(3f), rad, rad, shadowPaint)
        bodyPaint.shader = LinearGradient(
            0f, b.top, 0f, b.bottom, 0xFF3B1B70.toInt(), 0xFF170830.toInt(), Shader.TileMode.CLAMP
        )
        bodyPaint.alpha = (255 * p).toInt()
        c.drawRoundRect(b, rad, rad, bodyPaint)
        bodyPaint.alpha = 255
        neon(c, b, rad, color, 1.3f, p)

        textPaint.textSize = dp(34f)
        textPaint.color = mixWhite(color, 0.6f)
        textPaint.alpha = (255 * p).toInt()
        textPaint.setShadowLayer(dp(8f), 0f, 0f, color)
        val fm = textPaint.fontMetrics
        c.drawText(displayLabel(k), b.centerX(), b.top + (bh - r.height()) / 2f + dp(8f) - (fm.ascent + fm.descent) / 2f, textPaint)
        c.restore()
    }

    private fun keyAt(x: Float, y: Float): Key? {
        val g = dp(3f)
        for (row in keys) for (k in row) {
            val r = k.rect
            if (x >= r.left - g && x <= r.right + g && y >= r.top - g && y <= r.bottom + g) return k
        }
        return null
    }

    private fun fire(k: Key) {
        when (k.label) {
            "⇧" -> shift = !shift
            "⌫" -> listener?.onBackspace()
            "↵" -> listener?.onEnter()
            "SPACE" -> listener?.onText(" ")
            "123" -> setMode("NUM")
            "ABC", "EN" -> setMode("EN")
            "বাং", "কখ" -> setMode("BN1")
            "অআ" -> setMode("BN2")
            else -> {
                val text = if (mode == "EN" && shift) k.label.uppercase() else k.label
                listener?.onText(text)
                if (shift) shift = false
            }
        }
    }

    private fun press(k: Key, x: Float, y: Float) {
        for (row in keys) {
            if (!row.contains(k)) continue
            for (o in row) {
                if (o === k) continue
                val d = abs(o.rect.centerX() - k.rect.centerX())
                val reach = k.rect.width() * 2.6f
                if (d < reach) o.vel += 3.2f * (1f - d / reach)
            }
        }
        k.target = 1f
        k.holdUntil = System.nanoTime() + 140_000_000L
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        ripples.add(Ripple(x, y, System.nanoTime(), accentAt(x, y)))
        fire(k)
        if (k.label == "⌫") {
            repeatKey = k
            handler.postDelayed(repeatRunnable, 380)
        }
    }

    private fun release(k: Key) {
        k.target = 0f
        if (k === repeatKey) {
            repeatKey = null
            handler.removeCallbacks(repeatRunnable)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val k = keyAt(e.getX(i), e.getY(i))
                if (k != null) {
                    active[e.getPointerId(i)] = k
                    press(k, e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                active.remove(e.getPointerId(i))?.let { release(it) }
            }
            MotionEvent.ACTION_CANCEL -> {
                active.values.forEach { release(it) }
                active.clear()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatRunnable)
        super.onDetachedFromWindow()
    }
}
