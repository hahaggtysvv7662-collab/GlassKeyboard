package com.example.glasskeyboard

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class GlassKeyboardService : InputMethodService() {

    private var kb: GlassKeyboardView? = null

    private fun applyPrefs(v: GlassKeyboardView) {
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        v.applySettings(
            p.getInt("accent", 0),
            p.getInt("heightPct", 100),
            p.getBoolean("bangla", true),
            p.getBoolean("sound", true),
            p.getString("bg", null)
        )
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        kb?.let {
            applyPrefs(it)
            it.resetWord()
            it.playIntro()
        }
    }

    override fun onCreateInputView(): View {
        val view = GlassKeyboardView(this)
        kb = view
        applyPrefs(view)
        view.listener = object : GlassKeyboardView.Listener {
            override fun onText(text: String) {
                currentInputConnection?.commitText(text, 1)
            }

            override fun onBackspace() {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            }

            override fun onReplace(typed: String, word: String) {
                val ic = currentInputConnection ?: return
                val before = ic.getTextBeforeCursor(typed.length, 0)?.toString()
                if (before != null && before.equals(typed, ignoreCase = true)) {
                    ic.deleteSurroundingText(typed.length, 0)
                }
                ic.commitText("$word ", 1)
            }

            override fun onEnter() {
                val info = currentInputEditorInfo
                val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (noEnterAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
                } else {
                    currentInputConnection?.performEditorAction(action)
                }
            }
        }
        return view
    }

    override fun onEvaluateFullscreenMode(): Boolean = false
}
