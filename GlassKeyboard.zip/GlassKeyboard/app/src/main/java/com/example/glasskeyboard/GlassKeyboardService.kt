package com.example.glasskeyboard

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class GlassKeyboardService : InputMethodService() {

    private var kb: GlassKeyboardView? = null

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        kb?.setAccent(getSharedPreferences("kb", MODE_PRIVATE).getInt("accent", 0))
        kb?.playIntro()
    }

    override fun onCreateInputView(): View {
        val view = GlassKeyboardView(this)
        kb = view
        view.setAccent(getSharedPreferences("kb", MODE_PRIVATE).getInt("accent", 0))
        view.listener = object : GlassKeyboardView.Listener {
            override fun onText(text: String) {
                currentInputConnection?.commitText(text, 1)
            }

            override fun onBackspace() {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            }

            override fun onEnter() {
                val info = currentInputEditorInfo
                val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (noEnterAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
                } else {
                    currentInputConnection?.performEditorAction(action)
                }
            }
        }
        return view
    }

    override fun onEvaluateFullscreenMode(): Boolean = false
}
