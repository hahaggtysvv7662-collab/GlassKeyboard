package com.example.glasskeyboard

import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class GlassKeyboardService : InputMethodService() {

    private var kb: GlassKeyboardView? = null

    private fun applyPrefs(v: GlassKeyboardView) {
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        v.applySettings(
            p.getInt("accent", 0),
            p.getInt("heightPct", 100),
            p.getBoolean("bangla", true),
            p.getBoolean("sound", true),
            p.getString("bg", null),
            p.getFloat("lsL", 0.22f),
            p.getFloat("lsR", 0.78f),
            p.getFloat("lsH", 0.6f)
        )
    }

    private fun makeWindowTransparent() {
        try {
            window?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        } catch (e: Exception) {
            // keep the default background if the window cannot be changed
        }
    }

    override fun onWindowShown() {
        super.onWindowShown()
        makeWindowTransparent()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        makeWindowTransparent()
        kb?.let {
            applyPrefs(it)
            it.resetWord()
            it.playIntro()
        }
    }

    /** In landscape the keyboard is a small panel; touches outside it go to the app/game below. */
    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        val v = kb ?: return
        val r = Rect()
        if (v.isShown && v.compactRect(r)) {
            val loc = IntArray(2)
            v.getLocationInWindow(loc)
            r.offset(loc[0], loc[1])
            outInsets.touchableInsets = InputMethodService.Insets.TOUCHABLE_INSETS_REGION
            outInsets.touchableRegion.set(r)
        }
    }

    override fun onCreateInputView(): View {
        val view = GlassKeyboardView(this)
        kb = view
        applyPrefs(view)
        view.listener = object : GlassKeyboardView.Listener {
            override fun onText(text: String) {
                currentInputConnection?.commitText(text, 1)
            }

            override fun onBackspace() {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            }

            override fun onReplace(typed: String, word: String) {
                val ic = currentInputConnection ?: return
                val before = ic.getTextBeforeCursor(typed.length, 0)?.toString()
                if (before != null && before.equals(typed, ignoreCase = true)) {
                    ic.deleteSurroundingText(typed.length, 0)
                }
                ic.commitText("$word ", 1)
            }

            override fun onLayoutChanged(l: Float, r: Float, h: Float) {
                getSharedPreferences("kb", MODE_PRIVATE).edit()
                    .putFloat("lsL", l).putFloat("lsR", r).putFloat("lsH", h).apply()
            }

            override fun onEnter() {
                val info = currentInputEditorInfo
                val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (noEnterAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
                } else {
                    currentInputConnection?.performEditorAction(action)
                }
            }
        }
        return view
    }

    override fun onEvaluateFullscreenMode(): Boolean = false
}
